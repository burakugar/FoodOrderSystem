public class Admin extends User{


    @Override
    public String getMail() {
        return super.getMail();
    }

    @Override
    public String getPassword() {
        return super.getPassword();
    }

    @Override
    public String getID() {
        return super.getID();
    }

    @Override
    public void setPassword(String password) {
        super.setPassword(password);
    }

    @Override
    public void setID(String ID) {
        super.setID(ID);
    }

    @Override
    public void setMail(String mail) {
        super.setMail(mail);
    }
    public void addFood(Restaurant restaurant,Food item){


    }

    public void deleteFood(Restaurant restaurant,Food item){


    }
    public void updateFood(Restaurant restaurant,Food item){


    }
    public void addRestaurant(Restaurant restaurant){


    }
    public void DeleteRestaurant(Restaurant restaurant){


    }
    public void UpdateRestaurant(Restaurant restaurant){


    }

    public void addCustomer(Customer customer){


    }
    public void DeleteCustomer(Customer customer){


    }
    public void UpdateCustomer(Customer customer){


    }
    public void seeRestaurantsStats(Restaurant restaurant){


    }

    public void seeCustomerStats(Customer customer){




    }





}

public class Order {
    private OrderStatus stats;
    private Basket orderedBasket;

    public Basket getOrderedBasket() {
        return orderedBasket;
    }

    public OrderStatus getStats() {
        return stats;
    }

    public void setStats(OrderStatus stats) {
        this.stats = stats;
    }

    public void setOrderedBasket(Basket orderedBasket) {
        this.orderedBasket = orderedBasket;
    }

}

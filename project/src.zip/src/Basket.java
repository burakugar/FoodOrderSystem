import java.util.PriorityQueue;

public class Basket {
    PriorityQueue<Food> myBasket;
    public void add(Food food){


    }
    public void delete(Food food){


    }


}

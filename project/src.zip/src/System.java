import java.util.ArrayList;
import java.util.Iterator;
import java.util.PriorityQueue;

public class System {
    public ArrayList<Restaurant> restaurantList;
    public ArrayList<User> allUsers;
    public PriorityQueue<Restaurant> sortedRestaurant;
    
	public System(){

    }
    public void LogIn(User user1){


    }
    public void SignUp(){


    }
    
    public void voteRestaurant(Restaurant restaurant1,Double vote){
    	for(int i=0;i<restaurantList.size();i++) {
    		if(restaurantList.get(i).equals(restaurant1)) {
    			restaurantList.get(i).addVote(vote);
    		}
    	}
    		

    }
    public void voteRestaurantSorted(Restaurant restaurant1,Double vote){
    	Iterator<Restaurant> iterator = sortedRestaurant.iterator();
    	while(iterator.hasNext()) {
    		Restaurant rs = iterator.next();
    		if(rs.equals(restaurant1)) {
    			rs.addVote(vote);
    		}
    		
    	}
    		

    }
    public ArrayList<Restaurant> getRestaurantList() {
		return restaurantList;
	}
	public void setRestaurantList(ArrayList<Restaurant> restaurantList) {
		this.restaurantList = restaurantList;
	}


}

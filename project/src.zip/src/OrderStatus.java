public enum OrderStatus {
    PREPARING,
    ONTHEWAY,
    DELIVERED,
    CANCELLED
}

import java.util.ArrayList;

public class Customer extends User {
    private String address;
    private Basket myBasket;
    private Payment paymentType;
    private Order ordered;
    ArrayList<Restaurant> restaurantList;
    
    public Customer(ArrayList<Restaurant> restaurantList){
    	this.restaurantList = restaurantList;

    }
    public void voteRestaurant(Restaurant restaurant1){
    	

    }

    private void confirmBasket(){


    }

    public void setOrdered(Order ordered) {
        this.ordered = ordered;
    }

    public void setOrderStat(Order ordered,OrderStatus stat) {
        this.ordered.setStats(stat);
    }

    public void setPaymentType(Payment paymentType) {
        this.paymentType = paymentType;
    }

    public Basket getMyBasket() {
        return myBasket;
    }

    public Order getOrdered() {
        return ordered;
    }

    public Payment getPaymentType() {
        return paymentType;
    }

    @Override
    public String getMail() {
        return super.getMail();
    }

    @Override
    public String getPassword() {
        return super.getPassword();
    }

    @Override
    public String getID() {
        return super.getID();
    }

    @Override
    public void setPassword(String password) {
        super.setPassword(password);
    }

    @Override
    public void setID(String ID) {
        super.setID(ID);
    }

    @Override
    public void setMail(String mail) {
        super.setMail(mail);
    }

    public String getAddress() {
        return address;
    }



    public void setAddress(String address) {
        this.address = address;
    }


    public void searchByFoodName(String foodName){



    }

    public void searchByRestaurantName(String restaurantName){


    }
    public void displayAllRestaurant(){


    }

    public void displayRestaurant(int index){


    }
    public int findItemIndex(String name){
        return -1;
    }


    public void addItem(Food food){


    }
    public void removeItem(int index){


    }

    public void setPayment(Payment myPaymentType){

    }



}

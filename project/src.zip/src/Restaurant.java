import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Restaurant extends User {


        private Queue<Order> allOrder;
        private Queue<Customer> orderedCustomers;
        private BinarySearchTree<Food> allFood;
        private double averageStar=0.0;
        private LinkedList<Double> allVotes;
        private String openningTime="";
        private String closingTime="";
        
        public void UpdateMenu(Food item1,int newPrice){

	        if(allFood.contains(item1)){
	                allFood.delete(item1);  
	                item1.setPrice(newPrice);
	                allFood.add(item1);
	        }
	        else{
	                //Update edilecek foodun olmadığını belirten uyarı.
	                java.lang.System.out.println("There is an error when update menu.");
	        }

        }
        public void seeAllVotes(){
	        for(int i=0;i<allVotes.size();i++){
	                java.lang.System.out.println(allVotes.get(i));
	        }


        }
        public void addFood(Food item){
                //add item to Restaurant's menu.
                allFood.add(item);

        }

        public void deleteFood(Food item){
                //remove item from Restaurant's menu.
                if(allFood.contains(item)){
                        allFood.remove(item);
                }
                else{
                        java.lang.System.out.println("The food that trying to remove is not exist in menu.");
                }

        }
        /*
               public void updateOrderStatus(Customer customer){


        }*/

        public void updateOrderStatus(Customer customer,OrderStatus stat){
                if(allOrder.contains(customer.getOrdered())){
                        customer.setOrderStat(customer.getOrdered(),stat);
                }
                else{
                        // O sipariş ya da kullanıcının olmadığını belirten uyarı mesajı
                        java.lang.System.out.println("There is an error when updating order status.");
                }

        }
        @Override
        public String getMail() {
                return super.getMail();
        }

        @Override
        public String getPassword() {
                return super.getPassword();
        }

        @Override
        public String getID() {
                return super.getID();
        }

        @Override
        public void setPassword(String password) {
                super.setPassword(password);
        }

        @Override
        public void setID(String ID) {
                super.setID(ID);
        }

        @Override
        public void setMail(String mail) {
                super.setMail(mail);
        }

        public BinarySearchTree<Food> getAllFood() {
                return allFood;
        }

        public double getAverageStar() {
                return averageStar;
        }

        public Queue<Order> getAllOrder() {
                return allOrder;
        }

        public String getClosingTime() {
                return closingTime;
        }

        public String getOpenningTime() {
                return openningTime;
        }

        public void setClosingTime(String closingTime) {
                this.closingTime = closingTime;
        }

        public void setOpenningTime(String openningTime) {
                this.openningTime = openningTime;
        }

        public void setAllFood(BinarySearchTree<Food> allFood) {
                this.allFood = allFood;
        }

        public void setAllOrder(Queue<Order> allOrder) {
                this.allOrder = allOrder;
        }

        public void setAverageStar(double averageStar) {
                this.averageStar = averageStar;
        }
        public void addVote(Double vote) {
        	allVotes.add(vote);
        }
}
